//
//  main.m
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@.
//  Copyright © 2017 @@USER@@. All rights reserved.
//

#import "@@CLASSPREFIX@@AppDelegate.h"

int main(int argc, char *argv[]) {
	@autoreleasepool {
		return UIApplicationMain(argc, argv, nil, NSStringFromClass(@@CLASSPREFIX@@AppDelegate.class));
	}
}
