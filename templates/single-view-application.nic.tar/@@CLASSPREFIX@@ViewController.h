//
//  ViewController.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@.
//  Copyright © 2017 @@USER@@. All rights reserved.
//

@interface @@CLASSPREFIX@@ViewController : UIViewController

@end
