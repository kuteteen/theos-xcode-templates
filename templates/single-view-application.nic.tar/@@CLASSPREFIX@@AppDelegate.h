//
//  AppDelegate.h
//  @@FULLPROJECTNAME@@
//
//  Created by @@USER@@.
//  Copyright © 2017 @@USER@@. All rights reserved.
//

@interface @@CLASSPREFIX@@AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
